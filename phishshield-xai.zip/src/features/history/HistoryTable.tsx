import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ExternalLink,
  Mail,
  Globe,
  UploadCloud,
  Search,
  Filter,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  ShieldAlert,
  HelpCircle,
} from 'lucide-react';
import { HistoryItem, HistoryPage, InputType, Verdict } from '@/types';
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Pagination } from '@/components/ui/pagination';
import { formatDate, getVerdictTheme } from '@/lib/utils';
import { Input } from '@/components/ui/input';

export interface HistoryTableProps {
  data: HistoryPage | null;
  isLoading?: boolean;
  selectedVerdict: Verdict | 'ALL';
  selectedInputType: InputType | 'ALL';
  searchQuery: string;
  onVerdictChange: (v: Verdict | 'ALL') => void;
  onInputTypeChange: (t: InputType | 'ALL') => void;
  onSearchChange: (q: string) => void;
  onPageChange: (page: number) => void;
}

export function HistoryTable({
  data,
  isLoading = false,
  selectedVerdict,
  selectedInputType,
  searchQuery,
  onVerdictChange,
  onInputTypeChange,
  onSearchChange,
  onPageChange,
}: HistoryTableProps) {
  const navigate = useNavigate();

  const getTypeIcon = (type: InputType) => {
    switch (type) {
      case 'URL':
        return <Globe className="h-4 w-4 text-brand-medium" />;
      case 'EMAIL':
        return <Mail className="h-4 w-4 text-brand-medium" />;
      case 'EML':
        return <UploadCloud className="h-4 w-4 text-brand-medium" />;
    }
  };

  const getVerdictBadge = (verdict: Verdict | null) => {
    const meta = getVerdictTheme(verdict);
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold border ${meta.badgeClass}`}
      >
        <span>{meta.label}</span>
      </span>
    );
  };

  const getScoreColor = (score: number | null) => {
    if (score === null) return 'text-stone-500';
    if (score >= 70) return 'text-red-900 font-extrabold';
    if (score >= 40) return 'text-amber-900 font-bold';
    return 'text-emerald-900 font-bold';
  };

  return (
    <div className="space-y-4">
      {/* Filters Bar */}
      <div className="p-4 rounded-xl border border-brand-light/40 bg-brand-secondary/35 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-brand-dark/50">
            <Search className="h-4 w-4" />
          </div>
          <Input
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search by Host, Sender, or Analysis ID..."
            className="pl-9 h-9.5 text-xs bg-[#f4ebe1]"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Input Type Selector */}
          <div className="flex items-center space-x-1.5 text-xs">
            <span className="font-bold text-brand-dark/70 uppercase tracking-wider text-[11px]">Type:</span>
            <select
              value={selectedInputType}
              onChange={(e) => onInputTypeChange(e.target.value as InputType | 'ALL')}
              className="h-9 rounded-lg border border-brand-light/50 bg-[#f4ebe1] px-3 py-1 text-xs text-brand-dark font-medium focus:ring-2 focus:ring-brand-medium focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Types</option>
              <option value="EMAIL">Email</option>
              <option value="URL">URL</option>
              <option value="EML">EML File</option>
            </select>
          </div>

          {/* Verdict Selector */}
          <div className="flex items-center space-x-1.5 text-xs">
            <span className="font-bold text-brand-dark/70 uppercase tracking-wider text-[11px]">Verdict:</span>
            <select
              value={selectedVerdict}
              onChange={(e) => onVerdictChange(e.target.value as Verdict | 'ALL')}
              className="h-9 rounded-lg border border-brand-light/50 bg-[#f4ebe1] px-3 py-1 text-xs text-brand-dark font-medium focus:ring-2 focus:ring-brand-medium focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Verdicts</option>
              <option value="CRITICAL">Critical Risk</option>
              <option value="HIGH_RISK">High Risk</option>
              <option value="SUSPICIOUS">Suspicious</option>
              <option value="LOW_RISK">Low Risk</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <Table className="bg-[#ede3d5]/70">
        <TableHeader>
          <TableRow>
            <TableHead className="w-[140px]">Analysis ID</TableHead>
            <TableHead className="w-[100px]">Type</TableHead>
            <TableHead>Target / Sender Host</TableHead>
            <TableHead className="w-[90px] text-center">Score</TableHead>
            <TableHead className="w-[160px]">Verdict</TableHead>
            <TableHead className="w-[110px]">Status</TableHead>
            <TableHead className="w-[160px]">Timestamp</TableHead>
            <TableHead className="w-[60px] text-right">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={8} className="h-32 text-center text-sm text-brand-dark/70">
                Loading forensic analysis records...
              </TableCell>
            </TableRow>
          ) : !data || data.content.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="h-32 text-center text-sm text-brand-dark/70">
                No matching threat investigations found in history.
              </TableCell>
            </TableRow>
          ) : (
            data.content.map((item) => (
              <TableRow
                key={item.analysisId}
                onClick={() => navigate(`/analyses/${item.analysisId}`)}
                className="cursor-pointer hover:bg-brand-secondary/50 transition-colors group"
              >
                {/* ID */}
                <TableCell className="font-mono text-xs font-bold text-brand-dark">
                  {item.analysisId}
                </TableCell>

                {/* Type */}
                <TableCell>
                  <div className="flex items-center gap-1.5 text-xs font-semibold">
                    {getTypeIcon(item.inputType)}
                    <span>{item.inputType}</span>
                  </div>
                </TableCell>

                {/* Host */}
                <TableCell className="max-w-xs truncate font-medium text-xs text-brand-dark group-hover:text-brand-medium transition-colors" title={item.submittedHost}>
                  {item.submittedHost}
                </TableCell>

                {/* Score */}
                <TableCell className="text-center font-mono text-sm">
                  <span className={getScoreColor(item.riskScore)}>
                    {item.riskScore !== null ? item.riskScore : '—'}
                  </span>
                </TableCell>

                {/* Verdict */}
                <TableCell>{getVerdictBadge(item.verdict)}</TableCell>

                {/* Status */}
                <TableCell>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-brand-dark/70 bg-brand-secondary/50 px-2 py-0.5 rounded border border-brand-light/30">
                    {item.status}
                  </span>
                </TableCell>

                {/* Date */}
                <TableCell className="text-xs text-brand-dark/70 whitespace-nowrap">
                  {formatDate(item.createdAt)}
                </TableCell>

                {/* Action button */}
                <TableCell className="text-right">
                  <span className="p-1 rounded text-brand-dark/50 group-hover:text-brand-medium transition-colors inline-block">
                    <ExternalLink className="h-4 w-4" />
                  </span>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      {/* Pagination Controls */}
      {data && (
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2 text-xs text-brand-dark/70">
          <div>
            Showing <span className="font-bold text-brand-dark">{data.content.length}</span> of{' '}
            <span className="font-bold text-brand-dark">{data.totalElements}</span> recorded investigations
          </div>

          <Pagination
            currentPage={data.page}
            totalPages={data.totalPages}
            onPageChange={onPageChange}
          />
        </div>
      )}
    </div>
  );
}
