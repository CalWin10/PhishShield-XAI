import React, { useState } from 'react';
import { Globe, ArrowRight, Sparkles } from 'lucide-react';
import { ScanMode, UrlScanRequest } from '@/types';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScanModeSelector } from './ScanModeSelector';

export interface UrlScanFormProps {
  onSubmit: (data: UrlScanRequest) => void;
  isSubmitting?: boolean;
}

export function UrlScanForm({ onSubmit, isSubmitting = false }: UrlScanFormProps) {
  const [url, setUrl] = useState('');
  const [mode, setMode] = useState<ScanMode>('QUICK');
  const [error, setError] = useState<string | null>(null);

  const validateUrl = (val: string): boolean => {
    if (!val || !val.trim()) {
      setError('Please enter a target URL to analyze.');
      return false;
    }
    const trimmed = val.trim();
    if (!/^https?:\/\//i.test(trimmed)) {
      setError('URL must start with http:// or https://');
      return false;
    }
    try {
      new URL(trimmed);
      setError(null);
      return true;
    } catch {
      setError('Please enter a valid, well-formed URL.');
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateUrl(url)) return;

    onSubmit({
      url: url.trim(),
      mode,
    });
  };

  const handleSampleClick = (sampleUrl: string) => {
    setUrl(sampleUrl);
    setError(null);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="url-input" className="block text-xs font-bold uppercase tracking-wider text-brand-dark/80 mb-2">
          Target Uniform Resource Locator (URL) <span className="text-red-700">*</span>
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-brand-dark/50">
            <Globe className="h-5 w-5" />
          </div>
          <Input
            id="url-input"
            type="text"
            value={url}
            onChange={(e) => {
              setUrl(e.target.value);
              if (error) validateUrl(e.target.value);
            }}
            placeholder="https://secure-login.portal-verification.com/auth"
            className="pl-11 h-12 text-sm"
            error={!!error}
            disabled={isSubmitting}
            autoFocus
          />
        </div>
        {error && <p className="mt-1.5 text-xs font-medium text-red-700">{error}</p>}

        {/* Quick sample chips */}
        <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs text-brand-dark/70">
          <span className="font-semibold text-[11px] uppercase tracking-wider">Try Samples:</span>
          <button
            type="button"
            onClick={() => handleSampleClick('https://login.microsoftonline.portal-auth99.com/oauth2/authorize?client_id=common')}
            className="px-2 py-0.5 rounded bg-brand-secondary/40 hover:bg-brand-secondary/70 text-brand-dark text-[11px] font-mono border border-brand-light/30 transition-colors"
          >
            Spoofed Microsoft Login
          </button>
          <button
            type="button"
            onClick={() => handleSampleClick('https://accounts.google.com/signin/v2/identifier')}
            className="px-2 py-0.5 rounded bg-brand-secondary/40 hover:bg-brand-secondary/70 text-brand-dark text-[11px] font-mono border border-brand-light/30 transition-colors"
          >
            Legitimate Google Auth
          </button>
        </div>
      </div>

      {/* Mode Selector */}
      <ScanModeSelector mode={mode} onChange={setMode} disabled={isSubmitting} />

      {/* Submit Button */}
      <div className="pt-2">
        <Button
          type="submit"
          variant="primary"
          size="lg"
          isLoading={isSubmitting}
          className="w-full text-base font-bold shadow-md h-12"
        >
          <span>Initiate Threat Analysis</span>
          <ArrowRight className="h-5 w-5 ml-2" />
        </Button>
      </div>
    </form>
  );
}
