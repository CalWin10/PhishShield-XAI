import React, { useState } from 'react';
import { Mail, Globe, UploadCloud, Shield } from 'lucide-react';
import { EmailScanRequest, ScanMode, UrlScanRequest } from '@/types';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { EmailScanForm } from './EmailScanForm';
import { UrlScanForm } from './UrlScanForm';
import { EmlUploader } from './EmlUploader';

export interface SubmissionTabsProps {
  onScanEmail?: (data: EmailScanRequest) => void;
  onScanUrl?: (data: UrlScanRequest) => void;
  onScanEml?: (file: File, mode: ScanMode) => void;
  onEmailSubmit?: (data: EmailScanRequest) => void;
  onUrlSubmit?: (data: UrlScanRequest) => void;
  onEmlSubmit?: (file: File, mode: ScanMode) => void;
  isLoading?: boolean;
  isSubmitting?: boolean;
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export function SubmissionTabs({
  onScanEmail,
  onScanUrl,
  onScanEml,
  onEmailSubmit,
  onUrlSubmit,
  onEmlSubmit,
  isLoading = false,
  isSubmitting = false,
  activeTab = 'email',
  onTabChange,
}: SubmissionTabsProps) {
  const [tab, setTab] = useState(activeTab);

  const handleTabChange = (val: string) => {
    setTab(val);
    onTabChange?.(val);
  };

  const handleEmail = onScanEmail || onEmailSubmit || (() => {});
  const handleUrl = onScanUrl || onUrlSubmit || (() => {});
  const handleEml = onScanEml || onEmlSubmit || (() => {});
  const busy = isLoading || isSubmitting;

  return (
    <Card className="border-brand-light/40 bg-brand-secondary/40 shadow-sm overflow-hidden">
      <CardHeader className="pb-4 border-b border-brand-light/20 bg-brand-secondary/25">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <CardTitle className="text-xl font-bold text-brand-dark flex items-center gap-2">
              <Shield className="h-5 w-5 text-brand-medium" />
              Triage & Threat Ingestion Console
            </CardTitle>
            <CardDescription className="text-brand-dark/70 text-xs mt-0.5">
              Submit artifacts for explainable neural inspection and risk scoring
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-6">
        <Tabs value={tab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6 bg-brand-secondary/60">
            <TabsTrigger value="email" className="gap-2">
              <Mail className="h-4 w-4" />
              <span className="font-semibold">Email Content</span>
            </TabsTrigger>
            <TabsTrigger value="url" className="gap-2">
              <Globe className="h-4 w-4" />
              <span className="font-semibold">Target URL</span>
            </TabsTrigger>
            <TabsTrigger value="eml" className="gap-2">
              <UploadCloud className="h-4 w-4" />
              <span className="font-semibold">EML File</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="email" className="animate-in fade-in-50 duration-200">
            <EmailScanForm onSubmit={handleEmail} isSubmitting={busy} />
          </TabsContent>

          <TabsContent value="url" className="animate-in fade-in-50 duration-200">
            <UrlScanForm onSubmit={handleUrl} isSubmitting={busy} />
          </TabsContent>

          <TabsContent value="eml" className="animate-in fade-in-50 duration-200">
            <EmlUploader onSubmit={handleEml} isSubmitting={busy} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
