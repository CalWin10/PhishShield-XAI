import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Shield,
  Search,
  Zap,
  Lock,
  Cpu,
  FileCheck2,
  ArrowRight,
  ShieldAlert,
  Layers,
  Sparkles,
  Terminal,
  Server,
  Code2,
  Database,
  ExternalLink,
  ChevronRight,
  Activity,
  AlertTriangle,
  BrainCircuit,
  Fingerprint,
} from 'lucide-react';
import { GradientWaves } from '@/components/react-bits/GradientWaves';
import { CardSwap, Card } from '@/components/react-bits/CardSwap';
import { DecryptedText } from '@/components/react-bits/DecryptedText';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export function HomePage() {
  const navigate = useNavigate();

  const threatVectors = [
    {
      title: 'Domain Spoofing & Punycode',
      tag: 'CRITICAL SEVERITY',
      source: 'paypal-security-update.com',
      verdict: '94% Threat Score',
      details: 'Homoglyph spoofing mimicking trusted banking domain with hidden redirect chain to credential harvest form.',
      ioc: 'IOC: 185.220.101.5 / AS9009 (M247)',
    },
    {
      title: 'Executive BEC & Urgent Wire',
      tag: 'HIGH SEVERITY',
      source: 'ceo-office@corp-internal-finance.co',
      verdict: '89% Threat Score',
      details: 'Display name impersonation leveraging psychological urgency cues and SPF/DKIM alignment mismatch.',
      ioc: 'DKIM Fail: header.d=corp-internal-finance.co != dkim=corp.com',
    },
    {
      title: 'Quishing / QR Code Attachment',
      tag: 'CRITICAL SEVERITY',
      source: 'mfa-reset-notice.eml (Payload in PNG)',
      verdict: '96% Threat Score',
      details: 'Steganographic QR code in embedded image leading to simulated Microsoft 365 OAuth credential stealer.',
      ioc: 'Direct Link: https://ms-login-auth.azurewebsites.net/auth',
    },
    {
      title: 'Legitimate Vendor Invoice',
      tag: 'BENIGN / VERIFIED',
      source: 'billing@aws.amazon.com',
      verdict: '4% Low Risk',
      details: 'Validated cryptographic DKIM pass, standard DMARC policy enforcement, and authentic SPF envelope.',
      ioc: 'DMARC Pass: p=reject sp=reject pct=100',
    },
  ];

  const pipelineStages = [
    {
      step: '01',
      title: 'Multi-Modal Ingestion',
      desc: 'Parses raw RFC-822 email headers, MIME multipart bodies, EML attachments, and target URL syntactics.',
      icon: Terminal,
    },
    {
      step: '02',
      title: 'Domain & Auth Verification',
      desc: 'Validates SPF, DKIM public key signatures, DMARC alignment, WHOIS domain age, and SSL certificate entropy.',
      icon: Lock,
    },
    {
      step: '03',
      title: 'Explainable Transformer AI',
      desc: 'Evaluates psychological pressure tokens, deceptive anchor text, and semantic deception via fine-tuned LLMs.',
      icon: BrainCircuit,
    },
    {
      step: '04',
      title: 'SHAP Feature Attribution',
      desc: 'Calculates additive game-theoretic SHAP values to explain exactly which words, domains, or headers triggered the score.',
      icon: Layers,
    },
    {
      step: '05',
      title: 'Automated SOAR Protocols',
      desc: 'Prescribes precise containment steps: IP perimeter blocks, Exchange quarantine rules, and user password resets.',
      icon: Zap,
    },
  ];

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section with WebGL GradientWaves & CardSwap */}
      <div className="relative rounded-3xl overflow-hidden border border-brand-light/40 bg-brand-dark text-brand-bg shadow-2xl">
        {/* GradientWaves Background */}
        <div className="absolute inset-0 opacity-40 pointer-events-none">
          <GradientWaves
            horizonColor="#291C0E"
            waveColor="#6E473B"
            crestColor="#BEB5A9"
            speed={0.35}
            amplitude={2.2}
            waveScale={0.55}
            waveRatio={0.85}
            swell={28}
            turbulence={18}
            tilt={1.05}
            zoom={0.95}
            height={5.0}
            fogDepth={16}
            detail="medium"
            brightness={1.1}
            opacity={0.8}
            mouseInteraction={true}
          />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 px-6 py-12 sm:px-10 lg:px-14 lg:py-16 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Hero Column */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-brand-medium/40 border border-brand-light/30 backdrop-blur-md text-brand-bg text-xs font-semibold">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>Next-Gen Security Operations</span>
              <span className="text-brand-light font-mono">• v3.4 Active</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              Explainable AI Phishing Investigation &{' '}
              <span className="text-[#E1D4C2] underline decoration-brand-medium decoration-wavy">
                <DecryptedText
                  text="Automated Triage"
                  speed={45}
                  maxIterations={15}
                  animateOn="mount"
                  encryptedClassName="text-brand-light font-mono"
                />
              </span>
            </h1>

            <p className="text-sm sm:text-base text-[#BEB5A9] max-w-xl leading-relaxed">
              Detect deceptive email campaigns, spoofed domains, and zero-day credential harvesting with
              game-theoretic SHAP feature attribution and instant SOAR playbooks.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <Button
                variant="primary"
                size="lg"
                onClick={() => navigate('/scan')}
                className="gap-2 bg-[#E1D4C2] text-brand-dark hover:bg-white font-bold shadow-md hover:scale-[1.02] transition-transform"
              >
                <Search className="h-4 w-4" />
                <span>Launch Threat Ingestion Console</span>
              </Button>

              <Button
                variant="outline"
                size="lg"
                onClick={() => navigate('/dashboard')}
                className="gap-2 border-brand-light/50 text-[#E1D4C2] hover:bg-brand-medium/40 font-semibold"
              >
                <Activity className="h-4 w-4" />
                <span>View SOC Metrics</span>
              </Button>
            </div>

            {/* Micro Stats */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-brand-light/20 text-xs">
              <div>
                <div className="text-xl font-extrabold text-white font-mono">99.4%</div>
                <div className="text-[#BEB5A9] mt-0.5">XAI Detection Accuracy</div>
              </div>
              <div>
                <div className="text-xl font-extrabold text-white font-mono">&lt; 320ms</div>
                <div className="text-[#BEB5A9] mt-0.5">Sub-Second Quick Triage</div>
              </div>
              <div>
                <div className="text-xl font-extrabold text-white font-mono">100%</div>
                <div className="text-[#BEB5A9] mt-0.5">Explainable Attributions</div>
              </div>
            </div>
          </div>

          {/* Right Hero Column: Interactive CardSwap */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center min-h-[360px] relative">
            <div className="text-center mb-3">
              <span className="text-[11px] font-bold uppercase tracking-widest text-[#BEB5A9]">
                Live Threat Intelligence Stream
              </span>
            </div>

            <div className="w-full flex items-center justify-center">
              <CardSwap
                width={360}
                height={230}
                cardDistance={35}
                verticalDistance={28}
                delay={4200}
                skewAmount={3}
              >
                {threatVectors.map((item, idx) => (
                  <Card key={idx} className="flex flex-col justify-between p-5 bg-[#1f150b] border-brand-light/30">
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-brand-medium/50 text-[#E1D4C2] border border-brand-light/30">
                          {item.tag}
                        </span>
                        <span className="text-xs font-bold text-emerald-400 font-mono">{item.verdict}</span>
                      </div>
                      <h4 className="text-sm font-bold text-white line-clamp-1">{item.title}</h4>
                      <p className="text-xs text-[#BEB5A9] mt-1 line-clamp-2 leading-relaxed">{item.details}</p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-brand-light/20 flex items-center justify-between text-[11px] font-mono text-brand-light">
                      <span className="truncate max-w-[240px]">{item.ioc}</span>
                      <ChevronRight className="h-3.5 w-3.5 shrink-0" />
                    </div>
                  </Card>
                ))}
              </CardSwap>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Highlights Grid */}
      <div className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <Badge variant="brand" className="px-3 py-1 font-bold text-xs uppercase tracking-wider">
            Explainable AI Architecture
          </Badge>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-brand-dark tracking-tight">
            Transparent Decision-Making for SOC Analysts
          </h2>
          <p className="text-xs sm:text-sm text-brand-dark/75">
            PhishShield eliminates "black-box" uncertainty by surfacing mathematical SHAP attributions,
            deceptive token maps, and clear actionable mitigation protocols.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl border border-brand-light/40 bg-brand-secondary/35 shadow-xs hover:border-brand-medium/60 transition-colors space-y-3">
            <div className="h-10 w-10 rounded-xl bg-brand-dark text-brand-bg flex items-center justify-center">
              <Fingerprint className="h-5 w-5 text-[#E1D4C2]" />
            </div>
            <h3 className="text-base font-bold text-brand-dark">RFC-822 Deep Header Forensics</h3>
            <p className="text-xs text-brand-dark/75 leading-relaxed">
              Detects SPF softfailing, DKIM public signature invalidations, DMARC policy bypasses, and
              hidden <code className="font-mono bg-brand-secondary/60 px-1 py-0.5 rounded">Reply-To</code> routing discrepancies.
            </p>
          </div>

          <div className="p-6 rounded-2xl border border-brand-light/40 bg-brand-secondary/35 shadow-xs hover:border-brand-medium/60 transition-colors space-y-3">
            <div className="h-10 w-10 rounded-xl bg-brand-medium text-white flex items-center justify-center">
              <BrainCircuit className="h-5 w-5 text-[#E1D4C2]" />
            </div>
            <h3 className="text-base font-bold text-brand-dark">NLP Urgency & Coercion Detection</h3>
            <p className="text-xs text-brand-dark/75 leading-relaxed">
              Neural token scoring flags psychological urgency triggers, coercive billing threats, executive
              authority spoofing, and credential re-verification lures.
            </p>
          </div>

          <div className="p-6 rounded-2xl border border-brand-light/40 bg-brand-secondary/35 shadow-xs hover:border-brand-medium/60 transition-colors space-y-3">
            <div className="h-10 w-10 rounded-xl bg-brand-dark text-brand-bg flex items-center justify-center">
              <Zap className="h-5 w-5 text-[#E1D4C2]" />
            </div>
            <h3 className="text-base font-bold text-brand-dark">SOAR & Incident Response Playbooks</h3>
            <p className="text-xs text-brand-dark/75 leading-relaxed">
              Generates instant perimeter blocking rules, Active Directory password reset alerts, firewall IP blocks,
              and standardized PDF incident forensic dossiers.
            </p>
          </div>
        </div>
      </div>

      {/* 5-Step Pipeline Walkthrough */}
      <div className="p-8 rounded-3xl border border-brand-light/40 bg-[#ebe0d1] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-brand-light/30 pb-4">
          <div>
            <h3 className="text-lg font-bold text-brand-dark flex items-center gap-2">
              <Layers className="h-5 w-5 text-brand-medium" />
              Multi-Stage XAI Detection Pipeline
            </h3>
            <p className="text-xs text-brand-dark/70 mt-0.5">
              From raw telemetry ingestion to calibrated SHAP attribution in under 350 milliseconds
            </p>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/scan')}
            className="font-semibold text-xs border-brand-medium gap-1.5"
          >
            <span>Test Live Artifact</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {pipelineStages.map((stg) => {
            const Icon = stg.icon;
            return (
              <div key={stg.step} className="p-4 rounded-xl bg-brand-bg/70 border border-brand-light/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-xs px-2 py-0.5 rounded bg-brand-secondary/60 text-brand-dark">
                    {stg.step}
                  </span>
                  <Icon className="h-4 w-4 text-brand-medium" />
                </div>
                <h4 className="text-xs font-bold text-brand-dark">{stg.title}</h4>
                <p className="text-[11px] text-brand-dark/70 leading-relaxed">{stg.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Launch Action Banner */}
      <div className="p-8 rounded-3xl border border-brand-medium/50 bg-gradient-to-r from-brand-dark to-brand-medium text-brand-bg flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center space-x-2 text-xs font-mono text-emerald-400">
            <ShieldAlert className="h-4 w-4" />
            <span>SUSPICIOUS EMAIL OR URL DETECTED?</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Run an Instant Forensic Scan in Under 1 Second
          </h3>
          <p className="text-xs sm:text-sm text-[#BEB5A9]">
            Submit raw text, upload .eml files, or analyze target domains to receive calibrated threat scores and
            containment protocols immediately.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <Button
            variant="primary"
            size="lg"
            onClick={() => navigate('/scan')}
            className="gap-2 bg-[#E1D4C2] text-brand-dark hover:bg-white font-bold"
          >
            <span>Launch Triage Console</span>
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
