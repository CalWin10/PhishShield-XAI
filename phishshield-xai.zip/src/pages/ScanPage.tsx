import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Download, Sparkles, AlertCircle, RotateCcw, ExternalLink } from 'lucide-react';
import { AnalysisResult, EmailScanRequest, ScanMode, UrlScanRequest, ApiError } from '@/types';
import { analysisApi } from '@/api/analysisApi';
import { reportApi } from '@/api/reportApi';
import { SubmissionTabs } from '@/features/scan/SubmissionTabs';
import { RiskSummary } from '@/components/RiskSummary';
import { EvidenceList } from '@/components/EvidenceList';
import { RecommendedActionPanel } from '@/components/RecommendedActionPanel';
import { DeepScanProgress } from '@/components/DeepScanProgress';
import { FeedbackDialog } from '@/components/FeedbackDialog';
import { ApiErrorBanner } from '@/components/ApiErrorBanner';
import { Button } from '@/components/ui/button';
import { useAnalysisPolling } from '@/hooks/useAnalysisPolling';
import { Card } from '@/components/ui/card';
import { formatDate } from '@/lib/utils';

export function ScanPage() {
  const navigate = useNavigate();
  const [currentResult, setCurrentResult] = useState<AnalysisResult | null>(null);
  const [activeAnalysisId, setActiveAnalysisId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<ApiError | Error | null>(null);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);

  // Polling hook for asynchronous deep scan progression
  const shouldPoll =
    !!activeAnalysisId &&
    (currentResult?.status === 'QUEUED' || currentResult?.status === 'PROCESSING');

  const { pollCount } = useAnalysisPolling(
    shouldPoll ? activeAnalysisId : null,
    {
      enabled: shouldPoll,
      onComplete: (completedResult) => {
        setCurrentResult(completedResult);
      },
      onError: (err) => {
        console.error('Polling error:', err);
        setError(err);
      },
    }
  );

  const handleScanEmail = async (data: EmailScanRequest) => {
    setIsSubmitting(true);
    setError(null);
    try {
      const res = await analysisApi.analyseEmail(data);
      setCurrentResult(res);
      setActiveAnalysisId(res.analysisId);
    } catch (err: any) {
      setError(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleScanUrl = async (data: UrlScanRequest) => {
    setIsSubmitting(true);
    setError(null);
    try {
      const res = await analysisApi.analyseUrl(data);
      setCurrentResult(res);
      setActiveAnalysisId(res.analysisId);
    } catch (err: any) {
      setError(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleScanEml = async (file: File, mode: ScanMode) => {
    setIsSubmitting(true);
    setError(null);
    try {
      const res = await analysisApi.analyseEmailFile(file, mode);
      setCurrentResult(res);
      setActiveAnalysisId(res.analysisId);
    } catch (err: any) {
      setError(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetScan = () => {
    setCurrentResult(null);
    setActiveAnalysisId(null);
    setError(null);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-brand-light/30 pb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-brand-dark">
            Phishing Triage & Explainable AI Investigation
          </h1>
          <p className="mt-1 text-sm text-brand-dark/75 max-w-2xl leading-relaxed">
            Multi-modal Explainable AI engine evaluating header integrity, domain reputation,
            DKIM/SPF alignment, psychological urgency cues, and adversarial indicators.
          </p>
        </div>

        {currentResult && (
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(`/analyses/${currentResult.analysisId}`)}
              className="gap-1.5 font-semibold"
            >
              <ExternalLink className="h-4 w-4" />
              <span>Permalink</span>
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={handleResetScan}
              className="gap-1.5 font-semibold"
            >
              <RotateCcw className="h-4 w-4" />
              <span>New Scan</span>
            </Button>
          </div>
        )}
      </div>

      {/* Error Banner */}
      {error && (
        <ApiErrorBanner
          error={error}
          onDismiss={() => setError(null)}
          isRetrying={isSubmitting}
        />
      )}

      {/* Ingestion Tabs if no active result */}
      {!currentResult && (
        <div className="max-w-3xl mx-auto">
          <SubmissionTabs
            onScanEmail={handleScanEmail}
            onScanUrl={handleScanUrl}
            onScanEml={handleScanEml}
            isLoading={isSubmitting}
          />
        </div>
      )}

      {/* Investigation Details View */}
      {currentResult && (
        <div className="space-y-6">
          {/* Deep Scan Progress Stepper (when queued/processing) */}
          {(currentResult.status === 'QUEUED' || currentResult.status === 'PROCESSING') && (
            <DeepScanProgress
              result={currentResult}
              pollCount={pollCount}
            />
          )}

          {/* Results Area */}
          {currentResult.status === 'COMPLETE' && (
            <div className="space-y-6">
              {/* Risk Summary Gauge & Key Metrics */}
              <RiskSummary result={currentResult} />

              {/* Two Column Grid: Evidence Breakdown & Action Protocol */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-7 space-y-6">
                  <EvidenceList indicators={currentResult.indicators} />
                </div>

                <div className="lg:col-span-5 space-y-6">
                  <RecommendedActionPanel
                    result={currentResult}
                    onOpenFeedback={() => setIsFeedbackOpen(true)}
                  />

                  {/* Metadata Snapshot */}
                  {currentResult.submittedMetadata && (
                    <div className="p-4 rounded-xl border border-brand-light/30 bg-[#ece2d5] text-xs space-y-2">
                      <h4 className="font-bold text-brand-dark uppercase tracking-wider text-[11px]">
                        Target Vector Metadata
                      </h4>
                      {currentResult.submittedMetadata.from && (
                        <div>
                          <span className="font-semibold text-brand-dark/70">From: </span>
                          <span className="font-mono text-brand-dark break-all">
                            {currentResult.submittedMetadata.from}
                          </span>
                        </div>
                      )}
                      {currentResult.submittedMetadata.replyTo && (
                        <div>
                          <span className="font-semibold text-brand-dark/70">Reply-To: </span>
                          <span className="font-mono text-brand-dark break-all">
                            {currentResult.submittedMetadata.replyTo}
                          </span>
                        </div>
                      )}
                      {currentResult.submittedMetadata.subject && (
                        <div>
                          <span className="font-semibold text-brand-dark/70">Subject: </span>
                          <span className="text-brand-dark font-medium">
                            {currentResult.submittedMetadata.subject}
                          </span>
                        </div>
                      )}
                      {currentResult.submittedMetadata.url && (
                        <div>
                          <span className="font-semibold text-brand-dark/70">Target URL: </span>
                          <span className="font-mono text-brand-dark break-all">
                            {currentResult.submittedMetadata.url}
                          </span>
                        </div>
                      )}
                      {currentResult.submittedMetadata.fileName && (
                        <div>
                          <span className="font-semibold text-brand-dark/70">Uploaded File: </span>
                          <span className="font-mono text-brand-dark">
                            {currentResult.submittedMetadata.fileName}
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Failed Status Box */}
          {currentResult.status === 'FAILED' && (
            <Card className="border-red-300 bg-red-50 p-6 text-center">
              <AlertCircle className="h-10 w-10 text-red-700 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-red-950">Threat Inspection Pipeline Failed</h3>
              <p className="text-sm text-red-900 mt-1 max-w-md mx-auto">
                The analysis worker encountered an unrecoverable decoding error or parser timeout.
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={handleResetScan}
                className="mt-4 border-red-300 text-red-900"
              >
                Retry Analysis
              </Button>
            </Card>
          )}

          {/* Feedback Dialog */}
          <FeedbackDialog
            open={isFeedbackOpen}
            onOpenChange={setIsFeedbackOpen}
            analysisId={currentResult.analysisId}
          />
        </div>
      )}
    </div>
  );
}
