import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return '—';
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).format(date);
  } catch {
    return dateString;
  }
}

export function getVerdictTheme(verdict: string | null | undefined) {
  switch (verdict) {
    case 'CRITICAL':
      return {
        label: 'Critical Risk',
        badgeClass: 'bg-red-900/20 text-red-900 border-red-800/40 dark:bg-red-950/40 dark:text-red-300 dark:border-red-700/60',
        cardBg: 'bg-red-50/70 border-red-200',
        textClass: 'text-red-900',
        bgClass: 'bg-red-600',
        strokeClass: '#991b1b',
        iconName: 'AlertOctagon',
      };
    case 'HIGH_RISK':
      return {
        label: 'High Risk',
        badgeClass: 'bg-amber-900/20 text-amber-900 border-amber-800/40 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-700/60',
        cardBg: 'bg-amber-50/70 border-amber-200',
        textClass: 'text-amber-900',
        bgClass: 'bg-amber-600',
        strokeClass: '#d97706',
        iconName: 'AlertTriangle',
      };
    case 'SUSPICIOUS':
      return {
        label: 'Suspicious',
        badgeClass: 'bg-yellow-900/20 text-yellow-900 border-yellow-800/40 dark:bg-yellow-950/40 dark:text-yellow-300 dark:border-yellow-700/60',
        cardBg: 'bg-yellow-50/70 border-yellow-200',
        textClass: 'text-yellow-900',
        bgClass: 'bg-yellow-600',
        strokeClass: '#ca8a04',
        iconName: 'ShieldAlert',
      };
    case 'LOW_RISK':
      return {
        label: 'Low Risk / Legitimate',
        badgeClass: 'bg-emerald-900/20 text-emerald-900 border-emerald-800/40 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-700/60',
        cardBg: 'bg-emerald-50/70 border-emerald-200',
        textClass: 'text-emerald-900',
        bgClass: 'bg-emerald-600',
        strokeClass: '#059669',
        iconName: 'ShieldCheck',
      };
    default:
      return {
        label: 'Pending Assessment',
        badgeClass: 'bg-stone-200 text-stone-700 border-stone-300',
        cardBg: 'bg-stone-50 border-stone-200',
        textClass: 'text-stone-700',
        bgClass: 'bg-stone-500',
        strokeClass: '#78716c',
        iconName: 'HelpCircle',
      };
  }
}

export function getSeverityTheme(severity: string) {
  switch (severity) {
    case 'CRITICAL':
      return {
        label: 'Critical',
        badgeClass: 'bg-red-100 text-red-900 border-red-300 font-semibold',
      };
    case 'HIGH':
      return {
        label: 'High',
        badgeClass: 'bg-orange-100 text-orange-900 border-orange-300 font-semibold',
      };
    case 'MEDIUM':
      return {
        label: 'Medium',
        badgeClass: 'bg-amber-100 text-amber-900 border-amber-300 font-medium',
      };
    case 'LOW':
      return {
        label: 'Low',
        badgeClass: 'bg-emerald-100 text-emerald-900 border-emerald-300 font-medium',
      };
    case 'INFO':
    default:
      return {
        label: 'Info',
        badgeClass: 'bg-stone-100 text-stone-700 border-stone-300 font-normal',
      };
  }
}

export function getActionExplanation(action: string | null | undefined): { title: string; desc: string; variant: 'destructive' | 'warning' | 'caution' | 'success' | 'default' } {
  switch (action) {
    case 'BLOCK_AND_REPORT':
      return {
        title: 'Block and Report to SOC',
        desc: 'Immediate perimeter block recommended. Domain/sender exhibits severe malicious indicators with active weaponized payloads or credential harvesting.',
        variant: 'destructive',
      };
    case 'QUARANTINE':
      return {
        title: 'Quarantine Message Immediately',
        desc: 'Isolate this communication from user inboxes. High probability of phishing or credential theft tactics detected.',
        variant: 'destructive',
      };
    case 'INVESTIGATE':
      return {
        title: 'Perform In-Depth SOC Triage',
        desc: 'Anomalies detected in headers or domain age. Manual verification of sender authenticity and link redirection is advised before releasing.',
        variant: 'warning',
      };
    case 'ALLOW_WITH_CAUTION':
      return {
        title: 'Safe to Proceed with Standard Caution',
        desc: 'No known threat intelligence hits or malicious behavioral markers identified. Standard organizational security hygiene applies.',
        variant: 'success',
      };
    default:
      return {
        title: 'Analysis in Progress',
        desc: 'Evaluating threat vectors, telemetry signals, and behavioral heuristics...',
        variant: 'default',
      };
  }
}
