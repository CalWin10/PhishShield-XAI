import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield,
  Lock,
  KeyRound,
  UserCheck,
  CheckCircle2,
  AlertCircle,
  Fingerprint,
  Radio,
  ArrowRight,
} from 'lucide-react';
import { useAuth, UserRole } from '@/context/AuthContext';
import { DecryptedText } from '@/components/react-bits/DecryptedText';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function LoginPage() {
  const navigate = useNavigate();
  const { user, login, logout, isAuthenticated } = useAuth();

  const [email, setEmail] = useState('a.vance@defense.soc.local');
  const [password, setPassword] = useState('••••••••••••');
  const [selectedRole, setSelectedRole] = useState<UserRole>('SENIOR_THREAT_HUNTER');
  const [mfaCode, setMfaCode] = useState('849-201');
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const roles: { role: UserRole; title: string; clearance: string; desc: string }[] = [
    {
      role: 'TIER_1_ANALYST',
      title: 'Tier 1 Triage Analyst',
      clearance: 'LEVEL 3 - SECRET',
      desc: 'Ingest suspicious emails, review initial heuristic scores, assign triage tags.',
    },
    {
      role: 'SENIOR_THREAT_HUNTER',
      title: 'Senior Threat Hunter & ML Triage',
      clearance: 'LEVEL 4 - TOP SECRET',
      desc: 'Deep XAI forensic inspection, SHAP token analysis, ground-truth model feedback.',
    },
    {
      role: 'INCIDENT_COMMANDER',
      title: 'SOC Incident Commander',
      clearance: 'LEVEL 5 - EXECUTIVE',
      desc: 'Authorizes automated SOAR blocklists, Active Directory isolation, and executive briefing exports.',
    },
    {
      role: 'SECOPS_ADMIN',
      title: 'SecOps Administrator',
      clearance: 'LEVEL 5 - EXECUTIVE',
      desc: 'Full API gateway access, worker pipeline monitoring, and system configuration.',
    },
  ];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await login(email, selectedRole);
      setSuccess(true);
      setTimeout(() => {
        navigate('/scan');
      }, 900);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRoleQuickSelect = (r: UserRole) => {
    setSelectedRole(r);
    if (r === 'TIER_1_ANALYST') setEmail('j.chen@triage.soc.local');
    if (r === 'SENIOR_THREAT_HUNTER') setEmail('a.vance@defense.soc.local');
    if (r === 'INCIDENT_COMMANDER') setEmail('m.reyes@command.soc.local');
    if (r === 'SECOPS_ADMIN') setEmail('admin@phishshield.internal');
  };

  return (
    <div className="max-w-4xl mx-auto py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-brand-secondary/60 border border-brand-light/40 text-brand-dark text-xs font-semibold">
          <Fingerprint className="h-3.5 w-3.5 text-brand-medium" />
          <span>SOC Authentication Gateway</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-brand-dark tracking-tight">
          SecOps Identity & Clearance Verification
        </h1>
        <p className="text-xs sm:text-sm text-brand-dark/70">
          Sign in or switch analyst personas to access triage telemetry, forensic XAI dossiers, and automated SOAR actions.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        {/* Left: Login Form */}
        <div className="md:col-span-7">
          <Card className="border-brand-light/40 bg-brand-secondary/40 shadow-md">
            <CardHeader className="border-b border-brand-light/20 pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-bold text-brand-dark flex items-center gap-2">
                  <KeyRound className="h-5 w-5 text-brand-medium" />
                  <span>Analyst Credential Portal</span>
                </CardTitle>
                <Badge variant="outline" className="text-[10px] font-mono border-brand-medium/40 text-brand-dark">
                  2FA Enforced
                </Badge>
              </div>
              <CardDescription className="text-xs text-brand-dark/70">
                Authenticate with corporate credentials or select a pre-configured SOC persona below.
              </CardDescription>
            </CardHeader>

            <CardContent className="pt-6">
              {success ? (
                <div className="py-8 text-center space-y-3">
                  <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-800">
                    <CheckCircle2 className="h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-bold text-brand-dark">Clearance Verified</h3>
                  <p className="text-xs text-brand-dark/70 font-mono">
                    Redirecting to PhishShield Threat Ingestion Console...
                  </p>
                </div>
              ) : (
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-brand-dark/80 block">
                      Analyst Corporate Email / UPN
                    </label>
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-white/80 font-mono text-xs"
                      placeholder="analyst@domain.com"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-brand-dark/80 block">
                      Security Passphrase
                    </label>
                    <Input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-white/80 font-mono text-xs"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold uppercase tracking-wider text-brand-dark/80 block">
                        Hardware Security Token / TOTP 2FA
                      </label>
                      <span className="text-[10px] text-emerald-700 font-mono font-semibold">TOKEN SYNCED</span>
                    </div>
                    <Input
                      type="text"
                      value={mfaCode}
                      onChange={(e) => setMfaCode(e.target.value)}
                      className="bg-white/80 font-mono text-xs text-center tracking-widest font-bold"
                    />
                  </div>

                  <div className="pt-2">
                    <Button
                      type="submit"
                      variant="primary"
                      size="lg"
                      isLoading={isLoading}
                      className="w-full gap-2 font-bold text-xs"
                    >
                      <UserCheck className="h-4 w-4" />
                      <span>Authenticate & Enter SOC Session</span>
                    </Button>
                  </div>
                </form>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right: Active Role Persona Selector */}
        <div className="md:col-span-5 space-y-4">
          <div className="p-4 rounded-xl border border-brand-light/40 bg-brand-secondary/30 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-brand-dark/80">
                Quick-Select SOC Role Persona
              </h3>
              <span className="text-[10px] font-mono text-brand-dark/60">Demo Modes</span>
            </div>

            <div className="space-y-2">
              {roles.map((r) => {
                const isSelected = selectedRole === r.role;
                return (
                  <div
                    key={r.role}
                    onClick={() => handleRoleQuickSelect(r.role)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-brand-dark text-white border-brand-dark shadow-md'
                        : 'bg-brand-bg/60 border-brand-light/40 hover:bg-brand-secondary/40 text-brand-dark'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold">{r.title}</span>
                      <span
                        className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          isSelected ? 'bg-brand-medium text-white' : 'bg-brand-secondary/60 text-brand-dark'
                        }`}
                      >
                        {r.clearance}
                      </span>
                    </div>
                    <p
                      className={`text-[11px] mt-1 line-clamp-2 leading-relaxed ${
                        isSelected ? 'text-[#BEB5A9]' : 'text-brand-dark/70'
                      }`}
                    >
                      {r.desc}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Current Active User Badge */}
          {isAuthenticated && user && (
            <div className="p-4 rounded-xl border border-emerald-300 bg-emerald-50/80 text-emerald-950 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-700" />
                  Active SOC Session
                </span>
                <span className="font-mono text-[10px] bg-emerald-200/70 px-2 py-0.5 rounded text-emerald-900 font-bold">
                  {user.badgeId}
                </span>
              </div>
              <div className="text-xs space-y-0.5">
                <div className="font-bold text-emerald-950">{user.name}</div>
                <div className="text-emerald-800 font-mono text-[11px]">{user.email}</div>
                <div className="text-emerald-900 font-semibold text-[11px] pt-1">{user.roleTitle}</div>
              </div>
              <div className="pt-2 flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => navigate('/scan')}
                  className="w-full text-xs font-semibold border-emerald-400 text-emerald-950 hover:bg-emerald-100 gap-1.5"
                >
                  <span>Go to Threat Ingestion</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
