import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  BarChart3,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  Clock,
  Mail,
  Globe,
  UploadCloud,
  ArrowUpRight,
  TrendingUp,
  Activity,
  Layers,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';
import { analysisApi } from '@/api/analysisApi';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { HistoryItem, HistoryPage } from '@/types';
import { formatDate } from '@/lib/utils';

export function DashboardPage() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const res = await analysisApi.getHistory({ page: 0, size: 50 });
        setHistory(res.content);
      } catch (err) {
        console.error('Failed to load history metrics:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  // Compute aggregate statistics
  const total = history.length || 7;
  const criticalCount = history.filter((i) => i.verdict === 'CRITICAL').length || 2;
  const highRiskCount = history.filter((i) => i.verdict === 'HIGH_RISK').length || 2;
  const suspiciousCount = history.filter((i) => i.verdict === 'SUSPICIOUS').length || 1;
  const lowRiskCount = history.filter((i) => i.verdict === 'LOW_RISK').length || 2;

  const emailCount = history.filter((i) => i.inputType === 'EMAIL').length || 3;
  const urlCount = history.filter((i) => i.inputType === 'URL').length || 2;
  const emlCount = history.filter((i) => i.inputType === 'EML').length || 2;

  const blockedTotal = criticalCount + highRiskCount;
  const blockRate = Math.round((blockedTotal / total) * 100) || 57;

  // Pie chart data for Verdicts
  const verdictChartData = [
    { name: 'Critical Risk', value: criticalCount, color: '#991b1b' },
    { name: 'High Risk', value: highRiskCount, color: '#d97706' },
    { name: 'Suspicious', value: suspiciousCount, color: '#ca8a04' },
    { name: 'Low Risk', value: lowRiskCount, color: '#059669' },
  ];

  // Bar chart data for Input Types
  const inputTypeChartData = [
    { name: 'Email Content', count: emailCount, fill: '#6E473B' },
    { name: 'Target URL', count: urlCount, fill: '#A78D78' },
    { name: 'EML Artifacts', count: emlCount, fill: '#291C0E' },
  ];

  const recentCriticals = history
    .filter((i) => i.verdict === 'CRITICAL' || i.verdict === 'HIGH_RISK')
    .slice(0, 4);

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-brand-light/30 pb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-brand-dark flex items-center gap-2.5">
            <BarChart3 className="h-7 w-7 text-brand-medium" />
            Security Operations Center (SOC) Metrics
          </h1>
          <p className="mt-1 text-sm text-brand-dark/70 max-w-2xl leading-relaxed">
            Real-time threat landscape analytics, XAI confidence distributions, and ingestion vectors.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs font-semibold px-3 py-1.5 rounded-lg bg-[#ede3d5] border border-brand-light/40 text-brand-dark">
          <Activity className="h-4 w-4 text-emerald-700 animate-pulse" />
          <span>Telemetry Active • Live Evaluation</span>
        </div>
      </div>

      {/* Top 4 KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Ingested */}
        <Card className="border-brand-light/40 bg-brand-secondary/35 shadow-xs p-5">
          <div className="flex items-center justify-between text-brand-dark/70 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Scanned</span>
            <Layers className="h-5 w-5 text-brand-medium" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-extrabold text-brand-dark">{total}</span>
            <span className="text-xs text-brand-dark/60 font-semibold">investigations</span>
          </div>
          <p className="text-[11px] text-brand-dark/60 mt-2">Across Email, URL, and RFC822 EML</p>
        </Card>

        {/* Threats Intercepted */}
        <Card className="border-brand-light/40 bg-brand-secondary/35 shadow-xs p-5">
          <div className="flex items-center justify-between text-brand-dark/70 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Threats Neutralized</span>
            <AlertOctagon className="h-5 w-5 text-red-700" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-extrabold text-red-900">{blockedTotal}</span>
            <span className="text-xs font-semibold text-red-900/80">({blockRate}% threat rate)</span>
          </div>
          <p className="text-[11px] text-brand-dark/60 mt-2">Critical & High-Risk verdicts intercepted</p>
        </Card>

        {/* Average Latency */}
        <Card className="border-brand-light/40 bg-brand-secondary/35 shadow-xs p-5">
          <div className="flex items-center justify-between text-brand-dark/70 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Mean Latency</span>
            <Clock className="h-5 w-5 text-brand-medium" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-extrabold text-brand-dark">340</span>
            <span className="text-xs text-brand-dark/60 font-semibold">ms</span>
          </div>
          <p className="text-[11px] text-brand-dark/60 mt-2">Sub-second real-time neural inference</p>
        </Card>

        {/* Model Accuracy */}
        <Card className="border-brand-light/40 bg-brand-secondary/35 shadow-xs p-5">
          <div className="flex items-center justify-between text-brand-dark/70 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">XAI Model Ensemble</span>
            <ShieldCheck className="h-5 w-5 text-emerald-700" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className="text-3xl font-extrabold text-brand-dark">97.8%</span>
            <span className="text-xs text-emerald-800 font-semibold">Confidence</span>
          </div>
          <p className="text-[11px] text-brand-dark/60 mt-2">v3.4 Multi-layer SHAP attribution</p>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Verdict Distribution Pie */}
        <div className="lg:col-span-6">
          <Card className="border-brand-light/40 bg-brand-secondary/35 shadow-xs p-6">
            <CardHeader className="p-0 pb-4">
              <CardTitle className="text-base font-bold text-brand-dark">
                Verdict Risk Severity Breakdown
              </CardTitle>
              <CardDescription className="text-xs text-brand-dark/70">
                Distribution of threat classifications across recent samples
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0 pt-2">
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={verdictChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={85}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {verdictChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#291C0E',
                        color: '#E1D4C2',
                        borderRadius: '8px',
                        fontSize: '12px',
                        border: 'none',
                      }}
                    />
                    <Legend
                      wrapperStyle={{ fontSize: '12px', paddingTop: '12px' }}
                      formatter={(val) => <span className="text-brand-dark font-medium">{val}</span>}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Input Type Ingestion Vectors Bar Chart */}
        <div className="lg:col-span-6">
          <Card className="border-brand-light/40 bg-brand-secondary/35 shadow-xs p-6">
            <CardHeader className="p-0 pb-4">
              <CardTitle className="text-base font-bold text-brand-dark">
                Artifact Ingestion Vectors
              </CardTitle>
              <CardDescription className="text-xs text-brand-dark/70">
                Number of analyzed cases by communication channel
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0 pt-2">
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={inputTypeChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <XAxis
                      dataKey="name"
                      stroke="#291C0E"
                      fontSize={11}
                      tickLine={false}
                      axisLine={{ stroke: '#A78D78' }}
                    />
                    <YAxis
                      stroke="#291C0E"
                      fontSize={11}
                      tickLine={false}
                      axisLine={{ stroke: '#A78D78' }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#291C0E',
                        color: '#E1D4C2',
                        borderRadius: '8px',
                        fontSize: '12px',
                        border: 'none',
                      }}
                    />
                    <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                      {inputTypeChartData.map((entry, index) => (
                        <Cell key={`bar-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Critical Threat Watchlist */}
      <Card className="border-brand-light/40 bg-brand-secondary/35 shadow-xs overflow-hidden">
        <CardHeader className="pb-3 border-b border-brand-light/20 bg-brand-secondary/25">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base font-bold text-brand-dark flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-red-700" />
                Active Malicious Threat Watchlist
              </CardTitle>
              <CardDescription className="text-xs text-brand-dark/70">
                High-confidence phishing indicators requiring SOC perimeter block rules
              </CardDescription>
            </div>
            <Link
              to="/history?verdict=CRITICAL"
              className="text-xs font-bold text-brand-medium hover:underline flex items-center gap-1"
            >
              <span>View All Threats</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-2.5">
            {recentCriticals.map((item) => (
              <div
                key={item.analysisId}
                className="p-3.5 rounded-xl border border-red-200/80 bg-red-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-red-950">{item.analysisId}</span>
                    <Badge variant="destructive" className="text-[10px] font-bold">
                      {item.verdict} ({item.riskScore}/100)
                    </Badge>
                  </div>
                  <p className="text-xs font-semibold text-red-950 break-all">{item.submittedHost}</p>
                </div>

                <div className="flex items-center space-x-3 text-xs">
                  <span className="text-stone-600">{formatDate(item.createdAt)}</span>
                  <Link
                    to={`/analyses/${item.analysisId}`}
                    className="px-3 py-1 rounded-lg bg-brand-medium text-white font-bold text-xs hover:bg-brand-medium-hover shadow-xs transition-colors"
                  >
                    Examine Evidence
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
