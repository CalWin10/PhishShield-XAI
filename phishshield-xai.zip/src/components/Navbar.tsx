import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Shield,
  History,
  BarChart3,
  Scan,
  Activity,
  Home,
  BookOpen,
  User,
  LogOut,
  ChevronDown,
  Menu,
  X,
  Lock,
  Radio,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { DecryptedText } from '@/components/react-bits/DecryptedText';

export function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAuthenticated, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navItems = [
    { label: 'Home', path: '/', icon: Home, exact: true },
    { label: 'Scan & Triage', path: '/scan', icon: Scan },
    { label: 'Incident History', path: '/history', icon: History },
    { label: 'SOC Dashboard', path: '/dashboard', icon: BarChart3 },
    { label: 'Architecture & API', path: '/docs', icon: BookOpen },
  ];

  const handleNavClick = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-brand-light/30 bg-[#ded0bd]/95 backdrop-blur-md shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo & Brand */}
          <Link to="/" className="flex items-center space-x-3 group text-decoration-none">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-dark text-brand-bg shadow-sm group-hover:scale-105 transition-transform duration-200">
              <Shield className="h-6 w-6 text-[#E1D4C2]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-black tracking-tight text-brand-dark">PhishShield</span>
                <Badge
                  variant="brand"
                  className="text-[10px] uppercase font-bold tracking-wider py-0.5 px-1.5 border-brand-medium/40 text-brand-dark"
                >
                  XAI Engine
                </Badge>
              </div>
              <p className="text-[11px] text-brand-dark/70 font-medium tracking-tight -mt-0.5">
                Explainable Threat Intelligence Platform
              </p>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = item.exact
                ? location.pathname === item.path
                : item.path === '/scan'
                ? location.pathname === '/scan' || location.pathname.startsWith('/analyses/')
                : location.pathname.startsWith(item.path);

              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    'inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs lg:text-sm font-semibold transition-colors duration-150',
                    isActive
                      ? 'bg-brand-medium text-white shadow-xs'
                      : 'text-brand-dark hover:bg-brand-secondary/50'
                  )}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* User Profile & Auth / Status */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Connected Badge */}
            <div className="hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-brand-secondary/40 border border-brand-light/30 text-xs">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600"></span>
              </span>
              <span className="font-mono text-[11px] font-bold text-brand-dark">API v1</span>
            </div>

            {/* Analyst User Badge */}
            {isAuthenticated && user ? (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center space-x-2 p-1.5 rounded-xl border border-brand-light/40 bg-brand-secondary/40 hover:bg-brand-secondary/70 transition-colors text-left"
                >
                  <div className="h-7 w-7 rounded-lg bg-brand-dark text-[#E1D4C2] flex items-center justify-center font-bold text-xs">
                    {user.avatarInitials}
                  </div>
                  <div className="hidden sm:block text-left pr-1">
                    <div className="text-xs font-bold text-brand-dark line-clamp-1 leading-tight">{user.name}</div>
                    <div className="text-[10px] text-brand-dark/70 font-mono leading-tight">{user.badgeId}</div>
                  </div>
                  <ChevronDown className="h-3.5 w-3.5 text-brand-dark/70" />
                </button>

                {/* Dropdown */}
                {userDropdownOpen && (
                  <div
                    className="absolute right-0 mt-2 w-64 rounded-2xl border border-brand-light/50 bg-[#ede3d5] p-3 shadow-xl z-50 space-y-2"
                    onMouseLeave={() => setUserDropdownOpen(false)}
                  >
                    <div className="border-b border-brand-light/30 pb-2">
                      <p className="text-xs font-bold text-brand-dark">{user.name}</p>
                      <p className="text-[11px] text-brand-dark/70 font-mono truncate">{user.email}</p>
                      <Badge variant="outline" className="mt-1 text-[10px] font-mono border-brand-medium/50 text-brand-dark">
                        {user.roleTitle}
                      </Badge>
                    </div>

                    <div className="space-y-1 pt-1">
                      <Link
                        to="/login"
                        onClick={() => setUserDropdownOpen(false)}
                        className="flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-brand-dark hover:bg-brand-secondary/60 transition-colors"
                      >
                        <Lock className="h-3.5 w-3.5 text-brand-medium" />
                        <span>Switch Analyst Role / Clearance</span>
                      </Link>

                      <button
                        type="button"
                        onClick={() => {
                          logout();
                          setUserDropdownOpen(false);
                          navigate('/login');
                        }}
                        className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-red-900 hover:bg-red-100/60 transition-colors text-left"
                      >
                        <LogOut className="h-3.5 w-3.5" />
                        <span>End SOC Session (Sign Out)</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <Link to="/login">
                <Button variant="primary" size="sm" className="gap-1.5 font-bold text-xs">
                  <User className="h-3.5 w-3.5" />
                  <span>Analyst Sign In</span>
                </Button>
              </Link>
            )}

            {/* Mobile Menu Toggle Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-brand-dark hover:bg-brand-secondary/50"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-brand-light/30 bg-[#ded0bd] px-4 pt-3 pb-5 space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = item.exact
              ? location.pathname === item.path
              : item.path === '/scan'
              ? location.pathname === '/scan' || location.pathname.startsWith('/analyses/')
              : location.pathname.startsWith(item.path);

            return (
              <button
                key={item.path}
                type="button"
                onClick={() => handleNavClick(item.path)}
                className={cn(
                  'w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-semibold text-left transition-colors',
                  isActive
                    ? 'bg-brand-medium text-white shadow-xs'
                    : 'text-brand-dark hover:bg-brand-secondary/50'
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
          <div className="pt-2 border-t border-brand-light/30">
            <Link
              to="/login"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-xs font-bold text-brand-dark bg-brand-secondary/40"
            >
              <User className="h-4 w-4 text-brand-medium" />
              <span>Analyst Profile & Clearance Gateway</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

export default Navbar;
