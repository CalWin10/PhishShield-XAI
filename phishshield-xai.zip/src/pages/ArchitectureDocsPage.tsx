import React, { useState } from 'react';
import {
  Layers,
  Server,
  Cpu,
  Database,
  Code2,
  FileCode,
  CheckCircle2,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  BookOpen,
  Terminal,
  Activity,
  FileText,
  Copy,
  Check,
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DecryptedText } from '@/components/react-bits/DecryptedText';

export function ArchitectureDocsPage() {
  const [copiedContract, setCopiedContract] = useState(false);

  const openApiSample = `openapi: 3.0.3
info:
  title: PhishShield XAI Forensic API
  version: 3.4.0
  description: Multi-modal Explainable AI Threat Ingestion & SHAP Attribution Gateway
paths:
  /api/v1/scan/email:
    post:
      summary: Ingest and analyze email payload
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/EmailScanRequest'
      responses:
        '200':
          description: Synchronous Quick Scan Result
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/AnalysisResult'
        '202':
          description: Asynchronous Deep Scan Accepted
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/DeepScanJob'
  /api/v1/analyses/{analysisId}:
    get:
      summary: Retrieve detailed XAI forensic dossier
      parameters:
        - name: analysisId
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: Complete SHAP attribution & SOAR playbooks
  /api/v1/feedback/{analysisId}:
    post:
      summary: Submit analyst ground-truth feedback
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/AnalystFeedbackRequest'`;

  const microservices = [
    {
      name: 'Frontend Web App (React + Vite)',
      tech: 'React 19, TypeScript, Tailwind CSS, React Bits (GradientWaves, CardSwap, Counter, DecryptedText)',
      role: 'Client-side analyst portal, real-time XAI visualizer, RFC-822 / EML uploader, and SOC audit dashboard.',
      badge: 'PORT 3000 / WebGL',
    },
    {
      name: 'API Gateway & Orchestrator',
      tech: 'REST / OpenAPI 3.0, Spring Boot / Express',
      role: 'Authentication, rate limiting, request validation, idempotent job queueing, and SOAR rule compilation.',
      badge: '/api/v1',
    },
    {
      name: 'Explainable AI (ML Service)',
      tech: 'Python 3.11, PyTorch, Transformers (RoBERTa / DeBERTa), SHAP (Game-Theoretic Attributions)',
      role: 'Semantic deception extraction, psychological urgency scoring, deceptive URL parsing, and token-level SHAP weights.',
      badge: 'Sub-300ms Inference',
    },
    {
      name: 'Deep Scan Async Worker',
      tech: 'Celery / Redis / RabbitMQ, DNS / WHOIS / Certificate Resolvers, Sandbox detonation',
      role: 'DKIM signature validation, SPF/DMARC alignment check, punycode spoof detection, redirect chain expansion.',
      badge: 'Async 202 Polling',
    },
  ];

  const handleCopy = () => {
    navigator.clipboard.writeText(openApiSample);
    setCopiedContract(true);
    setTimeout(() => setCopiedContract(false), 2000);
  };

  return (
    <div className="space-y-10 pb-16">
      {/* Header */}
      <div className="border-b border-brand-light/30 pb-6 space-y-2">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-brand-secondary/60 border border-brand-light/40 text-brand-dark text-xs font-semibold">
          <BookOpen className="h-3.5 w-3.5 text-brand-medium" />
          <span>System Architecture & API Contracts</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-brand-dark tracking-tight">
          PhishShield Enterprise Multi-Tier Specification
        </h1>
        <p className="text-xs sm:text-sm text-brand-dark/75 max-w-3xl">
          Comprehensive blueprint detailing the microservices architecture, asynchronous worker pipelines,
          SHAP attribution mechanics, and OpenAPI 3.0 data contracts.
        </p>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid grid-cols-3 max-w-md mb-6">
          <TabsTrigger value="overview" className="gap-2 text-xs font-bold">
            <Layers className="h-4 w-4" />
            <span>Architecture</span>
          </TabsTrigger>
          <TabsTrigger value="contracts" className="gap-2 text-xs font-bold">
            <Code2 className="h-4 w-4" />
            <span>OpenAPI Contracts</span>
          </TabsTrigger>
          <TabsTrigger value="model" className="gap-2 text-xs font-bold">
            <Cpu className="h-4 w-4" />
            <span>XAI Model Card</span>
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {microservices.map((svc) => (
              <Card key={svc.name} className="border-brand-light/40 bg-brand-secondary/30 shadow-xs">
                <CardHeader className="pb-3 border-b border-brand-light/20">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-bold text-brand-dark">{svc.name}</CardTitle>
                    <Badge variant="outline" className="text-[10px] font-mono border-brand-medium/40 text-brand-dark">
                      {svc.badge}
                    </Badge>
                  </div>
                  <CardDescription className="text-xs font-mono text-brand-dark/70">
                    {svc.tech}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-3">
                  <p className="text-xs text-brand-dark/80 leading-relaxed">{svc.role}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Directory Hierarchy Breakdown */}
          <div className="p-6 rounded-2xl border border-brand-light/40 bg-brand-dark text-brand-bg shadow-md space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between text-brand-light pb-2 border-b border-brand-light/20">
              <span className="font-bold uppercase tracking-wider text-[11px] text-white">
                Multi-Repository Directory Topology
              </span>
              <span className="text-[10px] bg-brand-medium/50 px-2 py-0.5 rounded text-white">v3.4-prod</span>
            </div>
            <pre className="text-[11px] text-[#BEB5A9] overflow-x-auto leading-relaxed">
{`phishshield-xai/
├── frontend/             # React 19, Vite, Tailwind CSS, React Bits (GradientWaves, CardSwap, Counter, DecryptedText)
│   ├── src/api/          # REST client, Analysis API, Feedback API, Report API
│   ├── src/components/   # RiskSummary, EvidenceList, IndicatorCard, ActionPanel, UI library
│   ├── src/features/     # Scan forms (Email, URL, EML uploader), Polling stepper
│   ├── src/pages/        # HomePage, ScanPage, AnalysisPage, HistoryPage, DashboardPage, LoginPage, DocsPage
│   └── src/types/        # AnalysisResult, ThreatScore, Indicator, Feedback
├── backend/              # Spring Boot REST Gateway, Authentication, Task Queue Orchestrator
├── ml-service/           # Transformer NLP Classifier, SHAP Feature Explainer, Feature Extractor
├── deep-scan-worker/     # DKIM/SPF verification, WHOIS reputation, Async Job Consumer
└── contracts/            # OpenAPI 3.0 contracts and test fixtures`}
            </pre>
          </div>
        </TabsContent>

        {/* Contracts Tab */}
        <TabsContent value="contracts" className="space-y-4">
          <Card className="border-brand-light/40 bg-brand-secondary/20">
            <CardHeader className="pb-3 border-b border-brand-light/20">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-sm font-bold text-brand-dark">OpenAPI 3.0 Interface Contract</CardTitle>
                  <CardDescription className="text-xs text-brand-dark/70">
                    Defines strict REST JSON endpoints for scan submissions, polling, and analyst feedback.
                  </CardDescription>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCopy}
                  className="gap-1.5 text-xs font-semibold border-brand-medium"
                >
                  {copiedContract ? <Check className="h-3.5 w-3.5 text-emerald-700" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedContract ? 'Copied' : 'Copy Spec'}</span>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <pre className="p-4 rounded-xl bg-brand-dark text-brand-light font-mono text-xs overflow-x-auto max-h-96">
                {openApiSample}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Model Card Tab */}
        <TabsContent value="model" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="border-brand-light/40 bg-brand-secondary/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-brand-dark">
                  Model Architecture
                </CardTitle>
              </CardHeader>
              <CardContent className="text-xs text-brand-dark/80 space-y-2">
                <p><strong>Base Backbone:</strong> Fine-tuned DeBERTa-v3 + Domain Heuristic Ensemble</p>
                <p><strong>Vocabulary:</strong> 128,000 subwords specialized in security & deceptive lures</p>
                <p><strong>Training Corpus:</strong> 1.2M labeled enterprise phishing & benign emails</p>
              </CardContent>
            </Card>

            <Card className="border-brand-light/40 bg-brand-secondary/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-brand-dark">
                  Explainability Method
                </CardTitle>
              </CardHeader>
              <CardContent className="text-xs text-brand-dark/80 space-y-2">
                <p><strong>Attribution Algorithm:</strong> TreeSHAP & KernelSHAP</p>
                <p><strong>Convergence:</strong> 100 sample background approximations</p>
                <p><strong>Output:</strong> Positive/Negative marginal contribution per feature</p>
              </CardContent>
            </Card>

            <Card className="border-brand-light/40 bg-brand-secondary/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-bold uppercase tracking-wider text-brand-dark">
                  Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="text-xs text-brand-dark/80 space-y-2">
                <p><strong>Precision:</strong> 99.4% on high-confidence threshold (&gt;80)</p>
                <p><strong>False Positive Rate:</strong> &lt; 0.12% across benign corporate traffic</p>
                <p><strong>Inference Latency:</strong> 280ms average per artifact</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default ArchitectureDocsPage;
