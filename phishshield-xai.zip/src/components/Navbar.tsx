import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, History, BarChart3, Scan, Activity } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

export function Navbar() {
  const location = useLocation();

  const navItems = [
    { label: 'Scan & Triage', path: '/', icon: Scan },
    { label: 'Investigation History', path: '/history', icon: History },
    { label: 'SOC Dashboard', path: '/dashboard', icon: BarChart3 },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-brand-light/30 bg-[#ded0bd]/95 backdrop-blur-md shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo & Brand */}
          <Link to="/" className="flex items-center space-x-3 group text-decoration-none">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-dark text-brand-bg shadow-sm group-hover:scale-105 transition-transform duration-200">
              <Shield className="h-6 w-6 text-[#E1D4C2]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-black tracking-tight text-brand-dark">PhishShield</span>
                <Badge variant="brand" className="text-[10px] uppercase font-bold tracking-wider py-0.5 px-1.5 border-brand-medium/40 text-brand-dark">
                  XAI Engine
                </Badge>
              </div>
              <p className="text-[11px] text-brand-dark/70 font-medium tracking-tight -mt-0.5">
                Explainable Threat Intelligence Platform
              </p>
            </div>
          </Link>

          {/* Navigation Links */}
          <nav className="flex items-center space-x-1 sm:space-x-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive =
                item.path === '/'
                  ? location.pathname === '/' || location.pathname.startsWith('/analyses/')
                  : location.pathname.startsWith(item.path);

              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    'inline-flex items-center space-x-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors duration-150',
                    isActive
                      ? 'bg-brand-medium text-white shadow-xs'
                      : 'text-brand-dark hover:bg-brand-secondary/40'
                  )}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Status Indicator */}
          <div className="hidden lg:flex items-center space-x-3 text-xs text-brand-dark/80">
            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-brand-secondary/40 border border-brand-light/30">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600"></span>
              </span>
              <span className="font-semibold text-[11px] text-brand-dark">API v1 Connected</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
