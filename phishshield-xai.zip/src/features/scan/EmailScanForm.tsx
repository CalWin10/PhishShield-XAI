import React, { useState } from 'react';
import { Mail, ArrowRight, User, CornerDownRight, FileText } from 'lucide-react';
import { EmailScanRequest, ScanMode } from '@/types';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { ScanModeSelector } from './ScanModeSelector';

export interface EmailScanFormProps {
  onSubmit: (data: EmailScanRequest) => void;
  isSubmitting?: boolean;
}

interface FormErrors {
  from?: string;
  subject?: string;
  body?: string;
}

export function EmailScanForm({ onSubmit, isSubmitting = false }: EmailScanFormProps) {
  const [from, setFrom] = useState('');
  const [replyTo, setReplyTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [mode, setMode] = useState<ScanMode>('QUICK');
  const [errors, setErrors] = useState<FormErrors>({});

  const validate = (): boolean => {
    const newErrors: FormErrors = {};

    if (!from.trim()) {
      newErrors.from = 'From sender address is required (e.g., alert@service.com)';
    }

    if (!subject.trim()) {
      newErrors.subject = 'Email subject line is required';
    }

    if (!body.trim()) {
      newErrors.body = 'Email body text or headers are required for analysis';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    onSubmit({
      from: from.trim(),
      replyTo: replyTo.trim() ? replyTo.trim() : undefined,
      subject: subject.trim(),
      body: body.trim(),
      mode,
    });
  };

  const loadSamplePhish = () => {
    setFrom('PayPal Security Alert <secure-update@account-paypal-verification.xyz>');
    setReplyTo('phish-collector@stealth-drop.ru');
    setSubject('URGENT: Unauthorized access detected from Moscow. Verify in 24 hours.');
    setBody(`Dear client,

Your PayPal account was accessed from an unrecognized IP address (185.220.101.44 - Moscow, RU).

For your safety, certain account capabilities have been temporarily restricted. You have 24 hours to verify your identity, otherwise your account and all associated funds will be permanently suspended.

Please click the secure link below to confirm your credentials and update billing information immediately:
https://account-paypal-verification.xyz/restore-access?token=9821739

Regards,
PayPal Fraud & Risk Operations Team`);
    setErrors({});
  };

  const loadSampleLegit = () => {
    setFrom('GitHub Notifications <notifications@github.com>');
    setReplyTo('notifications@github.com');
    setSubject('[GitHub] A personal access token has expired');
    setBody(`Hi @security-team,

Your personal access token "CI-Deploy-Key" expired on August 30, 2026.

You can generate a new token in your account settings under Developer Settings > Personal access tokens.

Thank you,
The GitHub Team`);
    setErrors({});
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Sample Quick Load Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-lg bg-[#ede3d5] border border-brand-light/30 text-xs">
        <span className="font-bold text-brand-dark/80">Forensic Testing Samples:</span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadSamplePhish}
            className="px-2.5 py-1 rounded bg-red-100 hover:bg-red-200 text-red-900 font-semibold border border-red-200 transition-colors"
          >
            Load Phishing Sample
          </button>
          <button
            type="button"
            onClick={loadSampleLegit}
            className="px-2.5 py-1 rounded bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-semibold border border-emerald-200 transition-colors"
          >
            Load Legitimate Sample
          </button>
        </div>
      </div>

      {/* From & ReplyTo Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="from-input" className="block text-xs font-bold uppercase tracking-wider text-brand-dark/80 mb-1.5">
            Sender Address (From) <span className="text-red-700">*</span>
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-brand-dark/50">
              <User className="h-4 w-4" />
            </div>
            <Input
              id="from-input"
              value={from}
              onChange={(e) => {
                setFrom(e.target.value);
                if (errors.from) setErrors((prev) => ({ ...prev, from: undefined }));
              }}
              placeholder="support@company-auth.com"
              className="pl-9"
              error={!!errors.from}
              disabled={isSubmitting}
            />
          </div>
          {errors.from && <p className="mt-1 text-xs text-red-700">{errors.from}</p>}
        </div>

        <div>
          <label htmlFor="replyto-input" className="block text-xs font-bold uppercase tracking-wider text-brand-dark/80 mb-1.5">
            Reply-To Header (Optional)
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-brand-dark/50">
              <CornerDownRight className="h-4 w-4" />
            </div>
            <Input
              id="replyto-input"
              value={replyTo}
              onChange={(e) => setReplyTo(e.target.value)}
              placeholder="relay-target@different-domain.com"
              className="pl-9"
              disabled={isSubmitting}
            />
          </div>
          <p className="mt-1 text-[11px] text-brand-dark/60">Used to detect Return-Path and Reply-To divergency.</p>
        </div>
      </div>

      {/* Subject Line */}
      <div>
        <label htmlFor="subject-input" className="block text-xs font-bold uppercase tracking-wider text-brand-dark/80 mb-1.5">
          Email Subject Line <span className="text-red-700">*</span>
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-brand-dark/50">
            <Mail className="h-4 w-4" />
          </div>
          <Input
            id="subject-input"
            value={subject}
            onChange={(e) => {
              setSubject(e.target.value);
              if (errors.subject) setErrors((prev) => ({ ...prev, subject: undefined }));
            }}
            placeholder="URGENT: Verify your account immediately"
            className="pl-9"
            error={!!errors.subject}
            disabled={isSubmitting}
          />
        </div>
        {errors.subject && <p className="mt-1 text-xs text-red-700">{errors.subject}</p>}
      </div>

      {/* Body Textarea */}
      <div>
        <label htmlFor="body-input" className="block text-xs font-bold uppercase tracking-wider text-brand-dark/80 mb-1.5">
          Email Body Content or Raw Headers <span className="text-red-700">*</span>
        </label>
        <Textarea
          id="body-input"
          value={body}
          onChange={(e) => {
            setBody(e.target.value);
            if (errors.body) setErrors((prev) => ({ ...prev, body: undefined }));
          }}
          placeholder="Paste raw email body, hyperlinks, or RFC822 message payload here..."
          className="min-h-[140px]"
          error={!!errors.body}
          disabled={isSubmitting}
        />
        {errors.body && <p className="mt-1 text-xs text-red-700">{errors.body}</p>}
        <p className="mt-1 text-[11px] text-brand-dark/60">
          Raw content is sanitized and never stored in insecure client storage.
        </p>
      </div>

      {/* Mode Selector */}
      <ScanModeSelector mode={mode} onChange={setMode} disabled={isSubmitting} />

      {/* Submit Button */}
      <div className="pt-2">
        <Button
          type="submit"
          variant="primary"
          size="lg"
          isLoading={isSubmitting}
          className="w-full text-base font-bold shadow-md h-12"
        >
          <span>Analyze Email Content</span>
          <ArrowRight className="h-5 w-5 ml-2" />
        </Button>
      </div>
    </form>
  );
}
